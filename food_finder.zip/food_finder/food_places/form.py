from django import forms

class FoodPlaceForm(forms.Form):
    user_input = forms.CharField(
        max_length=255,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter food and location (e.g., "Pizza near 380001")',
        })
    )
