from django.apps import AppConfig


class FoodPlacesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'food_places'
