from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from .models import (
    Multicuisine, cafe, Fast_food, Bakery, Dessert, 
    Gujrati, North_Indian, South_Indian, Italian, Chinese
)

FOOD_TYPE_MODEL_MAP = {
    'multicuisine': Multicuisine,
    'cafe': cafe,
    'fast_food': Fast_food,
    'bakery': Bakery,
    'dessert': Dessert,
    'gujrati': Gujrati,
    'north_indian': North_Indian,
    'south_indian': South_Indian,
    'italian': Italian,
    'chinese': Chinese,
}

@csrf_exempt
def chatbot_view(request):
    # Reset the chatbot session on every page reload
    if request.method == 'GET':
        request.session.flush()  # Clear all session data to start fresh
        request.session['messages'] = []
        request.session['stage'] = 'start'

    messages = request.session.get('messages', [])
    stage = request.session.get('stage', 'start')

    if request.method == 'POST':
        user_input = request.POST.get('user_input', '').strip()

        # Stage 1: Start conversation
        if stage == 'start':
            bot_reply = "Hello! I'm Food Finder. How may I help you? \n  Please select a food type : multicuisine \t cafe \t fast_food \t bakery \t dessert \t gujrati \t north_indian \t south_indian \t italian \t chinese"
            messages.append({'sender': 'bot', 'text': bot_reply})
            stage = 'food_type'

        # Stage 2: Food type selection
        elif stage == 'food_type':
            if user_input.lower() in FOOD_TYPE_MODEL_MAP:
                request.session['food_type'] = user_input.lower()
                bot_reply = "Great choice! Please provide your location, including the pincode (e.g., Satellite 380015)."
                messages.append({'sender': 'user', 'text': user_input})
                messages.append({'sender': 'bot', 'text': bot_reply})
                stage = 'manual_location'
            else:
                bot_reply = "Invalid food type. Please select a valid option."
                messages.append({'sender': 'bot', 'text': bot_reply})

        # Stage 3: Manual location entry
        elif stage == 'manual_location':
            try:
                location, pincode = user_input.rsplit(' ', 1)
                food_type = request.session.get('food_type')
                model = FOOD_TYPE_MODEL_MAP.get(food_type)
                if model:
                    places = model.objects.filter(pincode=pincode)
                    if places.exists():
                        bot_reply = f"{places.count()} places found for {food_type.title()} in {location}:<br>"
                        for place in places:
                            google_maps_link = f"https://www.google.com/maps/search/?api=1&query={place.address.replace(' ', '+')}"
                            bot_reply += (
                                f"<b>{place.name}</b> - {place.address} "
                                f"<a href='{google_maps_link}' target='_blank'>View on Google Maps</a><br>"
                            )
                    else:
                        bot_reply = "Sorry, no information available for your location."
                else:
                    bot_reply = "Food type not found."
                    stage = 'start'
            except ValueError:
                bot_reply = "Invalid format. Please include your location and pincode (e.g., Satellite 380015)."
            messages.append({'sender': 'user', 'text': user_input})
            messages.append({'sender': 'bot', 'text': bot_reply})

    # Save session state
    request.session['messages'] = messages
    request.session['stage'] = stage
    return render(request, 'index.html', {'messages': messages})
