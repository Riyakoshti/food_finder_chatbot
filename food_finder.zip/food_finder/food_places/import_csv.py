import csv
from food_places.models import Restaurant  # Adjust this path to match your app

def import_csv(file_path):
    """
    Import data from a CSV file into the Restaurant model.
    """
    with open(file_path, 'r', encoding='ISO-8859-1') as file:
        reader = csv.DictReader(file)
        for row in reader:
            # Handle empty or invalid numeric fields
            hygiene_rating = row.get('hygiene_rating')
            hygiene_rating = float(hygiene_rating) if hygiene_rating and hygiene_rating.strip() else None
            
            rating = row.get('rating')
            rating = float(rating) if rating and rating.strip() else None
            
            pincode = row.get('pincode')
            pincode = int(float(pincode)) if pincode and pincode.strip() else None
            
            # Create the Restaurant object
            Restaurant.objects.create(
                name=row['name'],  # Adjust based on your CSV headers
                food_type=row['food_type'],
                address=row['address'],
                latitude=row['latitude'],
                longitude=row['longitude'],
                pincode=pincode,
                details_url=row.get('details_url', ''),
                hygiene_rating=hygiene_rating,
                rating=rating,
            )
