# # # from food_places.models import Pizza, Burger, Dosa, Sandwich, PaniPuri

# # # def populate_db():
# # #     # Pizza Places
# # #     Pizza.objects.bulk_create([
# # #         Pizza(name="La Pinoz Pizza", address="CG Road, Ahmedabad", pincode="380009", location="https://maps.google.com/?q=23.0225,72.5714", ratings=4.5),
# # #         Pizza(name="Domino's Pizza", address="Prahlad Nagar, Ahmedabad", pincode="380015", location="https://maps.google.com/?q=23.0258,72.5074", ratings=4.2),
# # #     ])

# # #     # Burger Places
# # #     Burger.objects.bulk_create([
# # #         Burger(name="Burger King", address="Vastrapur, Ahmedabad", pincode="380015", location="https://maps.google.com/?q=23.0396,72.5293", ratings=4.0),
# # #         Burger(name="McDonald's", address="Law Garden, Ahmedabad", pincode="380006", location="https://maps.google.com/?q=23.0306,72.5611", ratings=4.1),
# # #     ])

# # #     # Dosa Places
# # #     Dosa.objects.bulk_create([
# # #         Dosa(name="Sankalp", address="SG Highway, Ahmedabad", pincode="380054", location="https://maps.google.com/?q=23.0625,72.5077", ratings=4.6),
# # #         Dosa(name="Dasaprakash", address="Maninagar, Ahmedabad", pincode="380008", location="https://maps.google.com/?q=23.0067,72.6043", ratings=4.7),
# # #     ])

# # #     # Sandwich Places
# # #     Sandwich.objects.bulk_create([
# # #         Sandwich(name="SandwichworkZ", address="Navrangpura, Ahmedabad", pincode="380009", location="https://maps.google.com/?q=23.0312,72.5640", ratings=4.4),
# # #         Sandwich(name="Havmor Sandwich", address="Bodakdev, Ahmedabad", pincode="380054", location="https://maps.google.com/?q=23.0495,72.5057", ratings=4.3),
# # #     ])

# # #     # Pani Puri Places
# # #     PaniPuri.objects.bulk_create([
# # #         PaniPuri(name="Urban Chowk", address="Drive-In Road, Ahmedabad", pincode="380054", location="https://maps.google.com/?q=23.0463,72.5265", ratings=4.8),
# # #         PaniPuri(name="Manek Chowk", address="Old City, Ahmedabad", pincode="380001", location="https://maps.google.com/?q=23.0273,72.5797", ratings=4.9),
# # #     ])

# # #     print("Database populated successfully!")
# # import csv
# # from food_places.models import Bakery, cafe, Chinese, Dessert, Fast_food, Gujrati, Italian, Multicuisine, North_Indian, South_Indian

# # def populate_database():
# #     # Replace 'cleaned_easydinner.csv' with your CSV file path
# #     with open(r'D:\\Forth Year AI project\\food_finder\\cleaned_eazydinner1.csv', 'r') as file:
# #         reader = csv.DictReader(file)
        
# #         for row in reader:
# #             cuisine_type = row['food_type'].lower()  # Adjust column name as per your CSV
# #             if cuisine_type == 'bakery':
# #                 Bakery.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'cafe':
# #                 cafe.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'chinese':
# #                 Chinese.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'dessert':
# #                 Dessert.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'fast food':
# #                 Fast_food.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'gujrati':
# #                 Gujrati.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'italian':
# #                 Italian.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'multicuisine':
# #                 Multicuisine.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'north indian':
# #                 North_Indian.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             elif cuisine_type == 'south indian':
# #                 South_Indian.objects.create(name=row['name'], location=row['location'], details=row['details'])
# #             else:
# #                 print(f"Unknown cuisine type: {cuisine_type}")

# import csv
# from food_places.models import Multicuisine, cafe, Fast_food, Bakery, Dessert, Gujrati, North_Indian, South_Indian, Italian, Chinese

# def populate_database():
#     # File path for the CSV
#     csv_file_path = r'D:\\Forth Year AI project\\food_finder\\cleaned_eazydinner1.csv'

#     # Cuisine mapping to their respective models
#     cuisine_model_mapping = {
#         'multicuisine': Multicuisine,
#         'cafe': cafe,
#         'fast food': Fast_food,
#         'bakery': Bakery,
#         'dessert': Dessert,
#         'gujarati': Gujrati,
#         'north indian': North_Indian,
#         'south indian': South_Indian,
#         'italian': Italian,
#         'chinese': Chinese,
#     }

#     try:
#         with open(r'D:\\Forth Year AI project\\food_finder\\cleaned_eazydinner1.csv', 'r') as file:
#             csv_reader = csv.DictReader(file)
#             for row in csv_reader:
#                 cuisine_type = row['food_type'].lower()  # Ensure case-insensitive match

#                 # Check if the cuisine type exists in the mapping
#                 if cuisine_type in cuisine_model_mapping:
#                     model_class = cuisine_model_mapping[cuisine_type]

#                     # Create a new object in the database
#                     model_class.objects.create(
#                         name=row['name'],
#                         food_type=row['food_type'],
#                         address=row['address'],
#                         latitude=float(row['latitude']),
#                         longitude=float(row['longitude']),
#                         pincode=int(row['pincode']),
#                         details_url=row['details_url'],
#                         hygiene_rating=float(row['hygiene_rating']) if row['hygiene_rating'] else None,
#                         rating=float(row['rating']) if row['rating'] else None
#                     )
#                 else:
#                     print(f"Unknown cuisine type: {cuisine_type}")
#         print("Database populated successfully!")

#     except FileNotFoundError:
#         print(f"File not found: {csv_file_path}")
#     except KeyError as e:
#         print(f"Missing column in CSV: {e}")
#     except Exception as e:
#         print(f"An error occurred: {e}")
import csv
from food_places.models import *

def populate_database():
    csv_file_path = r'D:\\Forth Year AI project\\food_finder\\cleaned_easydinner1.csv'

    # Define a mapping of cuisine types to their respective Django models
    cuisine_models = {
        "multicuisine": Multicuisine,
        "cafe": cafe,
        "fast food": Fast_food,
        "bakery": Bakery,
        "dessert": Dessert,
        "gujarati": Gujrati,
        "north indian": North_Indian,
        "south indian": South_Indian,
        "italian": Italian,
        "chinese": Chinese,
    }

    # Track unknown cuisine types
    unknown_cuisines = set()

    try:
        with open(r'D:\\Forth Year AI project\\food_finder\\cleaned_eazydinner1.csv', 'r') as file:
            reader = csv.DictReader(file)

            for row in reader:
                # Get cuisine types and split them into a list
                cuisine_types = row['food_type'].lower().split(',')

                # Process each cuisine type separately
                for cuisine_type in cuisine_types:
                    cuisine_type = cuisine_type.strip()

                    # Check if the cuisine type is recognized
                    if cuisine_type in cuisine_models:
                        model = cuisine_models[cuisine_type]
                        # Create an entry in the corresponding model
                        model.objects.create(
                            name=row['name'],
                            food_type=row['food_type'],  # Keep the original unmodified type
                            address=row['address'],
                            latitude=float(row['latitude']),
                            longitude=float(row['longitude']),
                            pincode=int(row['pincode']),
                            details_url=row['details_url'],
                            hygiene_rating=float(row['hygiene_rating']) if row['hygiene_rating'] else None,
                            rating=float(row['rating']) if row['rating'] else None
                        )
                    else:
                        unknown_cuisines.add(cuisine_type)

        if unknown_cuisines:
            print(f"Unknown cuisine types: {', '.join(unknown_cuisines)}")

        print("Database populated successfully!")

    except FileNotFoundError:
        print(f"File not found: {csv_file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")
