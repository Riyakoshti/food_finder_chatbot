# from django.db import models

# class Multicuisine(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class cafe(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Fast_food(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Bakery(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Dessert(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Gujrati(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class North_Indian(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class South_Indian(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Italian(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name

# class Chinese(models.Model):
#     name = models.CharField(max_length=255)
#     food_type = models.CharField(max_length=255)
#     address = models.TextField()
#     latitude = models.FloatField()
#     longitude = models.FloatField()
#     pincode = models.IntegerField()
#     details_url = models.URLField()
#     hygiene_rating = models.FloatField(null=True, blank=True)
#     rating = models.FloatField(null=True, blank=True)

#     def google_maps_link(self):
#         return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

#     def __str__(self):
#         return self.name
from django.db import models

class BaseCuisine(models.Model):
    name = models.CharField(max_length=255)
    food_type = models.CharField(max_length=255)
    address = models.TextField()
    latitude = models.FloatField()
    longitude = models.FloatField()
    pincode = models.IntegerField()
    details_url = models.URLField()
    hygiene_rating = models.FloatField(null=True, blank=True)
    rating = models.FloatField(null=True, blank=True)

    class Meta:
        abstract = True

    def google_maps_link(self):
        return f"https://www.google.com/maps?q={self.latitude},{self.longitude}"

    def __str__(self):
        return self.name

class Multicuisine(BaseCuisine):
    pass

class cafe(BaseCuisine):
    pass

class Fast_food(BaseCuisine):
    pass

class Bakery(BaseCuisine):
    pass

class Dessert(BaseCuisine):
    pass

class Gujrati(BaseCuisine):
    pass

class North_Indian(BaseCuisine):
    pass

class South_Indian(BaseCuisine):
    pass

class Italian(BaseCuisine):
    pass

class Chinese(BaseCuisine):
    pass
