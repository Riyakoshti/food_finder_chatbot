from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Multicuisine
from .models import cafe
from .models import Fast_food
from .models import Bakery
from .models import Dessert
from .models import Gujrati
admin.site.register(Gujrati)
admin.site.register(cafe)
admin.site.register(Multicuisine)
admin.site.register(Dessert)
admin.site.register(Bakery)
admin.site.register(Fast_food)

from .models import North_Indian
admin.site.register(North_Indian)
from .models import South_Indian
admin.site.register(South_Indian)
from .models import Italian
admin.site.register(Italian)
from .models import Chinese
admin.site.register(Chinese)